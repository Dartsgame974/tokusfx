import { useState } from 'react';
import type { SoundSuggestion } from '../../types';
import { Check, X, Edit2 } from 'lucide-react';

const DEMO_SUGGESTIONS: SoundSuggestion[] = [
  {
    id: '1',
    title: 'Zero-One Henshin',
    series: 'Kamen Rider',
    season: 'Kamen Rider Zero-One',
    type: 'Henshin Sound',
    description: 'The transformation sound when Aruto transforms into Zero-One',
    status: 'pending',
    submittedAt: '2024-03-15T10:00:00Z',
    submittedBy: 'user123'
  }
];

export function AdminSuggestionsPage() {
  const [suggestions] = useState<SoundSuggestion[]>(DEMO_SUGGESTIONS);
  const [editingId, setEditingId] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-gray-950 py-12">
      <div className="max-w-7xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-8">Manage Suggestions</h1>
        
        <div className="bg-gray-900 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-800">
                <th className="px-6 py-3 text-left text-sm font-medium text-gray-300">Title</th>
                <th className="px-6 py-3 text-left text-sm font-medium text-gray-300">Series</th>
                <th className="px-6 py-3 text-left text-sm font-medium text-gray-300">Type</th>
                <th className="px-6 py-3 text-left text-sm font-medium text-gray-300">Status</th>
                <th className="px-6 py-3 text-left text-sm font-medium text-gray-300">Submitted</th>
                <th className="px-6 py-3 text-left text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-800">
              {suggestions.map((suggestion) => (
                <tr key={suggestion.id} className="hover:bg-gray-800/50">
                  <td className="px-6 py-4 text-sm text-white">{suggestion.title}</td>
                  <td className="px-6 py-4 text-sm text-gray-300">{suggestion.series}</td>
                  <td className="px-6 py-4 text-sm text-gray-300">{suggestion.type}</td>
                  <td className="px-6 py-4 text-sm">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${suggestion.status === 'approved' ? 'bg-green-100 text-green-800' : 
                        suggestion.status === 'rejected' ? 'bg-red-100 text-red-800' : 
                        'bg-yellow-100 text-yellow-800'}`}>
                      {suggestion.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-300">
                    {new Date(suggestion.submittedAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-300">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setEditingId(suggestion.id)}
                        className="p-1 hover:bg-gray-700 rounded"
                      >
                        <Edit2 className="w-4 h-4 text-blue-400" />
                      </button>
                      <button className="p-1 hover:bg-gray-700 rounded">
                        <Check className="w-4 h-4 text-green-400" />
                      </button>
                      <button className="p-1 hover:bg-gray-700 rounded">
                        <X className="w-4 h-4 text-red-400" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}