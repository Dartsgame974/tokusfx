import { useState } from 'react';
import { SoundCard } from '../components/ui/sound-card';
import type { SoundEffect, SoundType, Series } from '../types';

const DEMO_SOUNDS: SoundEffect[] = [
  {
    id: '1',
    title: 'Decade Henshin',
    series: 'Kamen Rider',
    season: 'Kamen Rider Decade',
    type: 'Henshin Sound',
    audioUrl: '#',
    imageUrl: 'https://images.unsplash.com/photo-1635805737707-575885ab0820?q=80&w=800',
    downloads: 1234,
    plays: 5678
  },
  {
    id: '2',
    title: 'Gokaiger Change',
    series: 'Super Sentai',
    season: 'Kaizoku Sentai Gokaiger',
    type: 'Henshin Sound',
    audioUrl: '#',
    imageUrl: 'https://images.unsplash.com/photo-1516571748831-5d81767b044d?q=80&w=800',
    downloads: 987,
    plays: 4321
  }
];

export function HomePage() {
  const [selectedSeries, setSelectedSeries] = useState<Series | 'all'>('all');
  const [selectedType, setSelectedType] = useState<SoundType | 'all'>('all');

  return (
    <div className="min-h-screen bg-gray-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-wrap gap-4 mb-8">
          <select
            className="bg-gray-800 text-white rounded-lg px-4 py-2"
            value={selectedSeries}
            onChange={(e) => setSelectedSeries(e.target.value as Series | 'all')}
          >
            <option value="all">All Series</option>
            <option value="Kamen Rider">Kamen Rider</option>
            <option value="Super Sentai">Super Sentai</option>
            <option value="Ultraman">Ultraman</option>
          </select>

          <select
            className="bg-gray-800 text-white rounded-lg px-4 py-2"
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as SoundType | 'all')}
          >
            <option value="all">All Types</option>
            <option value="Henshin Sound">Henshin Sound</option>
            <option value="Device or Weapon Sound">Device/Weapon Sound</option>
            <option value="Pets/Entity Sound">Pets/Entity Sound</option>
            <option value="Mecha">Mecha</option>
            <option value="Attack">Attack</option>
            <option value="Standby">Standby</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {DEMO_SOUNDS.map((sound) => (
            <SoundCard key={sound.id} sound={sound} />
          ))}
        </div>
      </div>
    </div>
  );
}