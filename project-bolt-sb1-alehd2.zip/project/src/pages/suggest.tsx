import { useState } from 'react';
import { Series, SoundType } from '../types';
import { Upload } from 'lucide-react';

export function SuggestPage() {
  const [formData, setFormData] = useState({
    title: '',
    series: '' as Series,
    season: '',
    type: '' as SoundType,
    description: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  return (
    <div className="min-h-screen bg-gray-950 py-12">
      <div className="max-w-2xl mx-auto px-4">
        <div className="bg-gray-900 rounded-lg p-8">
          <h1 className="text-3xl font-bold text-white mb-6">Suggest a Sound Effect</h1>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Title
              </label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                className="w-full bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Series
              </label>
              <select
                value={formData.series}
                onChange={(e) => setFormData({ ...formData, series: e.target.value as Series })}
                className="w-full bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                required
              >
                <option value="">Select Series</option>
                <option value="Kamen Rider">Kamen Rider</option>
                <option value="Super Sentai">Super Sentai</option>
                <option value="Ultraman">Ultraman</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Season
              </label>
              <input
                type="text"
                value={formData.season}
                onChange={(e) => setFormData({ ...formData, season: e.target.value })}
                className="w-full bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Sound Type
              </label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value as SoundType })}
                className="w-full bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                required
              >
                <option value="">Select Type</option>
                <option value="Henshin Sound">Henshin Sound</option>
                <option value="Device or Weapon Sound">Device/Weapon Sound</option>
                <option value="Pets/Entity Sound">Pets/Entity Sound</option>
                <option value="Mecha">Mecha</option>
                <option value="Attack">Attack</option>
                <option value="Standby">Standby</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Description
              </label>
              <textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600 min-h-[100px]"
                required
              />
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Audio File (MP3 or WAV, max 5MB)
                </label>
                <input
                  type="file"
                  accept=".mp3,.wav"
                  className="w-full bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Image (max 2MB)
                </label>
                <input
                  type="file"
                  accept="image/*"
                  className="w-full bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 transition-colors flex items-center justify-center"
            >
              <Upload className="w-4 h-4 mr-2" />
              Submit Suggestion
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}