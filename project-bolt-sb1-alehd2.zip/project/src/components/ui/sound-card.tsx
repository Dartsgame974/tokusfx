import { Play, Download, Volume2 } from 'lucide-react';
import type { SoundEffect } from '../../types';
import { cn } from '../../lib/utils';

interface SoundCardProps {
  sound: SoundEffect;
  className?: string;
}

export function SoundCard({ sound, className }: SoundCardProps) {
  return (
    <div className={cn(
      "bg-gray-900 rounded-lg overflow-hidden shadow-lg transition-transform hover:scale-105",
      className
    )}>
      <div className="relative h-48">
        <img 
          src={sound.imageUrl} 
          alt={sound.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <button className="p-4 rounded-full bg-red-600 hover:bg-red-700 transition-colors">
            <Play className="w-8 h-8 text-white" />
          </button>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="text-xl font-bold text-white mb-2">{sound.title}</h3>
        <div className="space-y-2">
          <p className="text-gray-400">{sound.series} - {sound.season}</p>
          <span className="inline-block px-3 py-1 rounded-full text-sm bg-gray-800 text-gray-300">
            {sound.type}
          </span>
        </div>
        
        <div className="mt-4 flex items-center justify-between">
          <div className="flex items-center space-x-4 text-gray-400">
            <div className="flex items-center">
              <Volume2 className="w-4 h-4 mr-1" />
              <span>{sound.plays}</span>
            </div>
            <div className="flex items-center">
              <Download className="w-4 h-4 mr-1" />
              <span>{sound.downloads}</span>
            </div>
          </div>
          
          <button className="px-4 py-2 bg-gold hover:bg-gold/90 text-black rounded-full flex items-center">
            <Download className="w-4 h-4 mr-2" />
            Download
          </button>
        </div>
      </div>
    </div>
  );
}