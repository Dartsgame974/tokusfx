export type Series = 'Kamen Rider' | 'Super Sentai' | 'Ultraman';

export type SoundType = 
  | 'Henshin Sound'
  | 'Device or Weapon Sound'
  | 'Pets/Entity Sound'
  | 'Mecha'
  | 'Attack'
  | 'Standby'
  | 'Other';

export interface SoundSuggestion {
  id: string;
  title: string;
  series: Series;
  season: string;
  type: SoundType;
  audioFile?: File;
  imageFile?: File;
  description: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
  submittedBy: string;
}